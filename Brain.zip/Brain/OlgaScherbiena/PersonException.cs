﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Net.Http;
using System.IO;
using System.Runtime;

namespace Brain 
{
    class PersonException
    {
       
        private bool check_logCreate;
        private bool check_Picture;

        public void check_log(string log)
        { 
            
            if(File.Exists(log))
            {
                check_logCreate = true;
            }
            else check_logCreate = false;
        }
        public void assembly()
        {
            var assembly = typeof(BitmapImage).GetType().Assembly;
            var AssemblyName = assembly.GetName().Name;
            var generatedFilename = AssemblyName + @".resources";
            check_Picture = false;
            foreach (var res in assembly.GetManifestResourceNames())
            {
                if (res == generatedFilename)
                {
                    check_Picture = true;
                    break;
                }
            }
        }
        public bool get_log()
        {
            return check_logCreate;
        }
        public bool get_png()
        {
            return check_Picture;
        }
    }
}
