﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Brain;
using System.Drawing;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для PartInfoForm.xaml
    /// </summary>
    public partial class PartInfoForm : Window
    {
        public PartInfoForm()
        {
            InitializeComponent();
        }
        
        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing part info form]\n[Returning to the main menu form]\n\n------------------------------\n\n");
            Menu_form menu_Form = new Menu_form();
            menu_Form.Show();
            this.Close();
        }

        public Part GetPart(int id)
        {
            /* Цей метод повертає частину мозку, визначену id */

            switch (id)
            {
                case Crown.id:
                    return new Crown();
                case Cerebellum.id:
                    return new Cerebellum();
                case Forehead.id:
                    return new Forehead();
                case Occiput.id:
                    return new Occiput();

                default:
                    return new Temporal();
            }
        }

        public PartInfoForm(int selected_id, Brain brain)
        {
            // Цей метод ініціалізує вікно в залежності від вибраної частини мозку, визначеної selected_id

            // TODO: Додати інші елементи частин мозку на вікно

            String res = string.Empty;
            File.AppendAllText("logs/tmplog.txt", "[Entering part info form]\n");
            InitializeComponent();
            Part temp = GetPart(selected_id);
            if (temp.GetType() == typeof(Crown)) // if (temp is Crown crown)
            {
                // Font font2 = new Font("", 9.0F, FontStyles.Bold);
                File.AppendAllText("logs/tmplog.txt", "[Showing crown info]\n");
                res = "      " + brain.Cr.Crown_info + "\n      " + brain.Cr.structure + "\n      " + brain.Cr.latin + "\n      " + brain.Cr.functions + "\n      " + brain.Cr.clinical_significance
                                          + "\n      " + brain.Cr.Lateral_intraparietal_area + "\n      " + brain.Cr.Ventral_intraparietal_area + "\n      " 
                                          + brain.Cr.Medial_intraparietal_area + brain.Cr.Front_intraparietal_area;
                string one = "Вищі кіркові функції, локалізовані в  тім'яній частці:";
                string two = "Особливості уражень тім'яної частки:";
                string third = "Латеральна внутрішньотім'яна ділянка";
                string four = "Вентральна внутрішньотім'яна ділянка";
                string five = "Медіальна внутрішньотім'яна ділянка";
                string six = "Передня внутрішньотім'яна ділянка";
                for (int i = 0; i < res.Length; ++i)
                {
                    if(i + 16 < res.Length && res.Substring(i, 16) == "Тім’яна частина:")
                    {
                        paragraph.Inlines.Add(new Run("Тім’яна частина: ") { FontWeight = FontWeights.Bold });
                        i += 16;
                    }
                    else if (i + 54 < res.Length && res.Substring(i, 54) == "Тім'яна частка обмежена трьома анатомічними кордонами:")
                    {
                        paragraph.Inlines.Add(new Run("Тім'яна частка обмежена трьома анатомічними кордонами:") { FontWeight = FontWeights.Bold });
                        i += 54;
                    }
                    else if (i + 16 < res.Length && res.Substring(i, 16) == "lobus parietalis")
                    {
                        paragraph.Inlines.Add(new Run("lobus parietalis") { FontWeight = FontWeights.Bold });
                        i += 15;
                    }
                    else if(res[i] >= '0' && res[i] <= '9' && !(res[i+1] >= '0' && res[i+1] <= '9') && !(res[i+1] == '-')) {
                        paragraph.Inlines.Add(new Run(("\n      ").ToString()));
                        paragraph.Inlines.Add(new Run((res[i]).ToString()));
                    }
                    else if (i + one.Length - 1 < res.Length && res.Substring(i, one.Length) == one)
                    {
                        paragraph.Inlines.Add(new Run((one + " ")) { FontWeight = FontWeights.Bold });
                        i += one.Length;
                    }
                    else if (i + two.Length - 1 < res.Length && res.Substring(i, two.Length) == two)
                    {
                        paragraph.Inlines.Add(new Run((two + " ")) { FontWeight = FontWeights.Bold });
                        i += two.Length;
                    }
                    else if (i + third.Length - 1 < res.Length && res.Substring(i, third.Length) == third)
                    {
                        paragraph.Inlines.Add(new Run((third + " ")) { FontWeight = FontWeights.Bold });
                        i += third.Length;
                    }
                    else if (i + four.Length - 1 < res.Length && res.Substring(i, four.Length) == four)
                    {
                        paragraph.Inlines.Add(new Run((four + " ")) { FontWeight = FontWeights.Bold });
                        i += four.Length;
                    }
                    else if (i + five.Length - 1 < res.Length && res.Substring(i, five.Length) == five)
                    {
                        paragraph.Inlines.Add(new Run((five + " ")) { FontWeight = FontWeights.Bold });
                        i += four.Length-1;
                    }
                    else if (i + six.Length - 1 < res.Length && res.Substring(i, six.Length) == six)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + six + " ")) { FontWeight = FontWeights.Bold });
                        i += six.Length - 1;
                    }
                    else
                    {
                        paragraph.Inlines.Add(new Run(res[i].ToString()));
                    }
                }
            }
            else if (temp.GetType() == typeof(Cerebellum))
            {
                File.AppendAllText("logs/tmplog.txt", "[Showing cerebellum info]\n");
                res = brain.Cer.Cerebellum_info +  brain.Cer.structure + brain.Cer.latin + brain.Cer.functions + brain.Cer.clinical_significance;
                string title1 = "Мозочок";
                string title2 = "Мозочок  займає";
                string title3 = "Ураження мозочку";
                string title4 = "cerebellum";
                string title5 = "Особливістю мозочка";
                for (int i = 0; i < res.Length; ++i){
                    if (i + title2.Length < res.Length && res.Substring(i, title2.Length) == title2)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title2)) { FontWeight = FontWeights.Bold });
                        i += title2.Length;
                    }
                    else if (i != 0 && i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length-1;
                    }
                    else if (i == 0 && i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length - 1;
                    }
                    else if (i + title3.Length < res.Length && res.Substring(i, title3.Length) == title3)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title3 + " ")) { FontWeight = FontWeights.Bold });
                        i += title3.Length - 1;
                    }
                    else if (i + title4.Length < res.Length && res.Substring(i, title4.Length) == title4)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title4)) { FontWeight = FontWeights.Bold });
                        i += title4.Length - 1;
                    }
                    else if (i + title5.Length < res.Length && res.Substring(i, title5.Length) == title5)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title5)) { FontWeight = FontWeights.Bold });
                        i += title5.Length - 1;
                    }
                    else {
                        paragraph.Inlines.Add(new Run(res[i].ToString()));
                    }
                }
            }
            else if (temp.GetType() == typeof(Forehead))
            {
                File.AppendAllText("logs/tmplog.txt", "[Showing forehead info]\n");
                res = brain.Fr.Forehead_info + brain.Fr.structure + brain.Fr.latin + brain.Fr.functions + brain.Fr.clinical_significance;
                string title1 = "lobus frontalis";
                string title2 = "Лобова частка";
                string title3 = "Загальні наслідки пошкодження лобової частки";
                string title4 = "Одна з чотирьох великих часток кори головного мозку.";
                for (int i = 0; i < res.Length; ++i)
                {
                    if (i != 0 && i + title2.Length < res.Length && res.Substring(i, title2.Length) == title2)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title2+" ")) { FontWeight = FontWeights.Bold });
                        i += title2.Length;
                    }
                    else if (i == 0 && i + title4.Length < res.Length && res.Substring(i, title4.Length) == title4)
                    {
                        paragraph.Inlines.Add(new Run(("      " + title4 + " ")) { FontWeight = FontWeights.Bold });
                        i += title4.Length;
                    }
                    else if (i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length - 1;
                    }
                    else if (i + title3.Length < res.Length && res.Substring(i, title3.Length) == title3)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title3)) { FontWeight = FontWeights.Bold });
                        i += title3.Length - 1;
                    }
                    else if (i + title4.Length < res.Length && res.Substring(i, title4.Length) == title4)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title4 + " ")) { FontWeight = FontWeights.Bold });
                        i += title4.Length - 1;
                    }
                    else
                    {
                        paragraph.Inlines.Add(new Run(res[i].ToString()));
                    }
                }
            }
            else if (temp.GetType() == typeof(Occiput))
            {
                File.AppendAllText("logs/tmplog.txt", "[Showing occiput info]\n");
                res = brain.Occ.Occiput_info + brain.Occ.structure + brain.Occ.latin + brain.Occ.functions + brain.Occ.clinical_significance + brain.Occ.First_functional_area + brain.Occ.Ventral_flow + brain.Occ.Dorsomedial_flow;
                string title1 = "Потилична частина";
                string title2 = "Дві потиличні частини";
                string title3 = "lobus occipitalis";
                string title4 = "Перша функціональна область";
                string title5 = "Вентральний потік";
                string title6 = "Дорсомедіальний (ДМ)";
                for (int i = 0; i < res.Length; ++i)
                {
                    if (i + title2.Length < res.Length && res.Substring(i, title2.Length) == title2)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title2)) { FontWeight = FontWeights.Bold });
                        i += title2.Length;
                    }
                    else if (i != 0 && i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length - 1;
                    }
                    else if (i == 0 && i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length - 1;
                    }
                    else if (i + title3.Length < res.Length && res.Substring(i, title3.Length) == title3)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title3 + " ")) { FontWeight = FontWeights.Bold });
                        i += title3.Length - 1;
                    }
                    else if (i + title4.Length < res.Length && res.Substring(i, title4.Length) == title4)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title4)) { FontWeight = FontWeights.Bold });
                        i += title4.Length - 1;
                    }
                    else if (i + title5.Length < res.Length && res.Substring(i, title5.Length) == title5)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title5)) { FontWeight = FontWeights.Bold });
                        i += title5.Length - 1;
                    }
                    else if (i + title6.Length < res.Length && res.Substring(i, title6.Length) == title6)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title6)) { FontWeight = FontWeights.Bold });
                        i += title6.Length - 1;
                    }
                    else
                    {
                        paragraph.Inlines.Add(new Run(res[i].ToString()));
                    }
                }
            }
            else
            {
                File.AppendAllText("logs/tmplog.txt", "[Showing temporal info]\n");
                res = brain.Tmp.Temporal_info + brain.Tmp.structure + brain.Tmp.latin + brain.Tmp.functions + brain.Tmp.Function.otic + 
                    brain.Tmp.Function.visual + brain.Tmp.Function.speech_recognition + "\n      " + brain.Tmp.clinical_significance;
                string title1 = "Скронева частина";
                string title2 = "Скронева частка";
                string title3 = "Lobus temporalis";
                string title4 = "Області скроневої частки,";
                string title5 = "пошкодження медіальної скроневої частки";
                for (int i = 0; i < res.Length; ++i)
                {
                    if (i + title2.Length < res.Length && res.Substring(i, title2.Length) == title2)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title2)) { FontWeight = FontWeights.Bold });
                        i += title2.Length-1;
                    }
                    else if (i != 0 && i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length - 1;
                    }
                    else if (i == 0 && i + title1.Length < res.Length && res.Substring(i, title1.Length) == title1)
                    {
                        paragraph.Inlines.Add(new Run(("      " + title1)) { FontWeight = FontWeights.Bold });
                        i += title1.Length - 1;
                    }
                    else if (i + title3.Length < res.Length && res.Substring(i, title3.Length) == title3)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title3 + " ")) { FontWeight = FontWeights.Bold });
                        i += title3.Length - 1;
                    }
                    else if (i + title4.Length < res.Length && res.Substring(i, title4.Length) == title4)
                    {
                        paragraph.Inlines.Add(new Run(("\n      " + title4)) { FontWeight = FontWeights.Bold });
                        i += title4.Length - 1;
                    }
                    else if (i + title5.Length < res.Length && res.Substring(i, title5.Length) == title5)
                    {
                        paragraph.Inlines.Add(new Run((title5)) { FontWeight = FontWeights.Bold });
                        i += title5.Length - 1;
                    }
                    else
                    {
                        paragraph.Inlines.Add(new Run(res[i].ToString()));
                    }
                }
            }
            
        }

        private void Button_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing main menu form]\n[Opening info search form]\n\n------------------------------\n\n");
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void FlowDocumentScrollViewer_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            ScrollViewer scv = (ScrollViewer)sender;
            scv.ScrollToVerticalOffset(scv.VerticalOffset - e.Delta);
            e.Handled = true;
        }

        int k = 0;
        private void FlowDocumentScrollViewer_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            ScrollViewer scv = (ScrollViewer)sender;
            scv.ScrollToVerticalOffset(scv.VerticalOffset - e.Delta);
            e.Handled = true;
        }

        private void Label_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            Simulation simulation = new Simulation();
            simulation.Show();
            this.Close();
        }
    }
}
