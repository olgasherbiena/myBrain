﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для PartInfoForm.xaml
    /// </summary>
    public partial class PartInfoForm : Window
    {
        public PartInfoForm()
        {
            InitializeComponent();
        }
        
        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Menu_form menu_Form = new Menu_form();
            menu_Form.Show();
            this.Close();
        }

        private Part GetPart(int id)
        {
            /* Цей метод повертає частину мозку, визначену id */

            switch (id)
            {
                case Crown.id:
                    return new Crown();
                case Cerebellum.id:
                    return new Cerebellum();
                case Forehead.id:
                    return new Forehead();
                case Occiput.id:
                    return new Occiput();

                default:
                    return new Temporal();
            }
        }
        public PartInfoForm(int selected_id, Brain brain)
        {
            /* Цей метод ініціалізує вікно в залежності від вибраної частини мозку, визначеної selected_id */

            // TODO: Додати інші елементи частин мозку на вікно
            InitializeComponent();
            Part temp = GetPart(selected_id);
            if (temp.GetType() == typeof(Crown)) // if (temp is Crown crown)
            {
                label1.Content = brain.Cr.Crown_info;
            }
            else if (temp.GetType() == typeof(Cerebellum))
            {
                label1.Content = brain.Cer.Cerebellum_info;
            }
            else if (temp.GetType() == typeof(Forehead))
            {
                label1.Content = brain.Fr.Forehead_info;
            }
            else if (temp.GetType() == typeof(Occiput))
            {
                label1.Content = brain.Occ.Occiput_info;
            }
            else
            {
                label1.Content = brain.Tmp.Temporal_info;
            }

        }
    }
}
