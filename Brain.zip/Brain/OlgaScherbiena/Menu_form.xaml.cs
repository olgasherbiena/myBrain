﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Menu_form : Window
    {
        public Menu_form()
        {
            //Main menu init
            InitializeComponent();
            text.Text = "      Кожен з нас щодня ходить, спить, гуляє, дивиться на щось або когось і навіть не замислюється, "+
                        "що його мозок ніколи не спить."+
                         "\n      Даний додаток допоможе вам в цьому переконатися, також ви зможете дізнатися багато нової та цікавої інформації в довіднику." +
                         "\n      Даний проект розроблений за ініціативою студентів 2 курсу Національного університету «Запорізька Політехніка»."+
                         "\n      Ми висловлюємо окрему вдячність сайтам flaticon.com та icons8.com за надані ресурси."+
                "\n     Завдяки вашим донатам наш проект існує і може просуватися, тож будь ласка підтримайте нас якщо вам також подобається даний проект: 4731185627333955";

            File.OpenWrite("logs/tmplog.txt").Close();
            File.AppendAllText("logs/tmplog.txt", "[Entering main menu]\n");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Entering Dev menu
            File.AppendAllText("logs/tmplog.txt", "[Closing main menu form]\n[Opening developers form]\n\n------------------------------\n\n");
            Window1 from = new Window1();
            from.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //Exiting Program
            File.AppendAllText("logs/tmplog.txt", "[Exiting program]\n");
            string log = "logs/" + DateTime.Now.ToString("yyyy-dd-M---HH-mm-ss") + " log.txt";
            string[] logstring=File.ReadAllLines("logs/tmplog.txt");
            File.Create(log).Close();
            File.WriteAllText(log, "[Program started]\n\n------------------------------\n\n");
            File.AppendAllLines(log, logstring);
            File.Delete("logs/tmplog.txt");
            PersonException exception = new PersonException();
            exception.check_log(log);
            if (!exception.get_log())
            { MessageBox.Show("Помилка створення логу", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
            this.Close();
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing main menu form]\n[Opening info search form]\n\n------------------------------\n\n");
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing main menu form]\n[Opening brain simulation form]\n\n------------------------------\n\n");
            Simulation simulation = new Simulation();
            simulation.Show();
            this.Close();
        }
    }
}
