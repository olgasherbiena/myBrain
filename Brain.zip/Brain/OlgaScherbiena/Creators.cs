﻿using System;

namespace Brain
{
    // Клас розробників
    public struct student
    {
        public string initials;
        public int group_number;
        public string faculty;
        public string task;
    }
    class Creators
    {
        private student[] people;
        public Creators()
        {
            people = new student[5];
            people[0].initials = "Баклицька Анастасія";
            people[0].group_number = 111;
            people[0].faculty = "Інженерія програмного забезпечення";
            people[0].task = "Обробка виключних ситуацій";

            people[1].initials = "Васильченко Ярослав";
            people[1].group_number = 111;
            people[1].faculty = "Інженерія програмного забезпечення";
            people[1].task = "Робота з даними";

            people[2].initials = "Скорик Сергій";
            people[2].group_number = 111;
            people[2].faculty = "Інженерія програмного забезпечення";
            people[2].task = "Розроблення алгоритмів програми";

            people[3].initials = "Бейник Владислав";
            people[3].group_number = 121;
            people[3].faculty = "Інженерія програмного забезпечення";
            people[3].task = "Розроблення класів програми";

            people[4].initials = "Щербина Ольга";
            people[4].group_number = 121;
            people[4].faculty = "Інженерія програмного забезпечення";
            people[4].task = "Розроблення інтерфейсу програми";
        }
        public student[] People { set { } get { return people; } }
    }
}
