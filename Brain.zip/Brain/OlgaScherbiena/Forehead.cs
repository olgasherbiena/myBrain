﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brain
{
    public class Forehead:Part
    {
        public const int id = 120;
        // Зберігається загальна інформація про лобову частину (та що одразу після заголовку)
        private string forehead_name; 
        public Forehead()
        {
            forehead_name = "frh_part";
            structure = "frh_struct";
            latin = "frh_lat";
            functions = "frh_func";
            clinical_significance = "frh_clinic";
        }
        public string Forehead_name { set { forehead_name = value; } get { return forehead_name; } }
        public override string ToString()
        {
            return $"{id}; Name: {this.forehead_name}; Latin: {this.latin}; Functions: {this.functions}";
        }
    }
}
