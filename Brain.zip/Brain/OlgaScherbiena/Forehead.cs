﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Brain
{
    public class Forehead:Part
    {
        public const int id = 120;
        // Зберігається загальна інформація про лобову частину (та що одразу після заголовку)
        private string forehead_info; 
        public Forehead()
        {
            name_part = "Лобова частина";
            forehead_info = "frh_part";
            structure = "frh_struct";
            latin = "frh_lat";
            functions = "frh_func";
            clinical_significance = "frh_clinic";
            function_for_list = "керування рухами та мислення";
        }
        public string Forehead_info { set { forehead_info = value; } get { return forehead_info; } }
        public override string ToString()
        {
            return $"{this.name_part} ({this.latin}): {this.function_for_list}";
        }

        public void Forehead_Deserealise(string filename, Forehead tmp)
        {
            try
            { 
            string[] jsontext = File.ReadAllLines(filename);
            tmp.forehead_info = jsontext[1];
            tmp.forehead_info = forehead_info.Substring(forehead_info.IndexOf(": ") + 3);
            tmp.forehead_info = forehead_info.Substring(0, forehead_info.Length - 2);

            tmp.structure = jsontext[2];
            tmp.structure = structure.Substring(structure.IndexOf(": ") + 3);
            tmp.structure = structure.Substring(0, structure.Length - 2);

            tmp.latin = jsontext[3];
            tmp.latin = latin.Substring(latin.IndexOf(": ") + 3);
            tmp.latin = latin.Substring(0, latin.Length - 2);

            tmp.functions = jsontext[4];
            tmp.functions = functions.Substring(functions.IndexOf(": ") + 3);
            tmp.functions = functions.Substring(0, functions.Length - 2);

            tmp.clinical_significance = jsontext[5];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf(": ") + 3);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 1);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не знайдено\n" + ex.FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Forehead_XML(string filename, Forehead tmp)
        {
            try
            { 
            string[] xmltext = File.ReadAllLines(filename);
            tmp.forehead_info = xmltext[2];
            tmp.forehead_info = forehead_info.Substring(forehead_info.IndexOf("<cerebellum_name>") + 17);
            tmp.forehead_info = forehead_info.Substring(0, forehead_info.Length - 18);

            tmp.structure = xmltext[3];
            tmp.structure = structure.Substring(structure.IndexOf("<structure>") + 11);
            tmp.structure = structure.Substring(0, structure.Length - 12);

            tmp.latin = xmltext[4];
            tmp.latin = latin.Substring(latin.IndexOf("<latin>") + 7);
            tmp.latin = latin.Substring(0, latin.Length - 8);

            tmp.functions = xmltext[5];
            tmp.functions = functions.Substring(functions.IndexOf("<functions>") + 11);
            tmp.functions = functions.Substring(0, functions.Length - 12);

            tmp.clinical_significance = xmltext[6];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf("<clinical_significance>") + 23);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 24);
        }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не знайдено\n" + ex.FileName, "Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
}

    }
}
