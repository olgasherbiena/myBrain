﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Brain
{
    public class Occiput:Part
    {
        public const int id = 102;
        private string occiput_info; // Зберігається загальна інформація про потиличну частину (та що одразу після заголовку)
        private string first_functional_area;
        private string ventral_flow;
        private string dorsomedial_flow;
        public Occiput() // змінна variation створена тільки для імітації роботи з файлом
        {
                name_part = "Потилична частина";
                occiput_info = "occ_part";
                structure = "occ_struct";
                latin = "occ_lat";
                functions = "occ_func";
                clinical_significance = "occ_4";
                first_functional_area = "occ_1";
                ventral_flow = "occ_2";
                dorsomedial_flow = "occ_3";
                function_for_list = "зір";
        }
        public string Occiput_info { set { occiput_info = value; } get { return occiput_info; } }
        public string First_functional_area { set { first_functional_area = value; } get { return first_functional_area; } }
        public string Ventral_flow { set { ventral_flow = value; } get { return ventral_flow; } }
        public string Dorsomedial_flow { set { dorsomedial_flow = value; } get { return dorsomedial_flow; } }

        public override string ToString()
        {
            return $"{this.name_part} ({this.latin}): {this.function_for_list}";
        }

        // Функція для зчитування інформації з файлу типу .JSON
        public void Occiput_Deserealise(string filename, Occiput occ)
        {
            string[] jsontext = File.ReadAllLines(filename);
            occ.occiput_info = jsontext[1];
            occ.occiput_info = occiput_info.Substring(occiput_info.IndexOf(": ") + 3);
            occ.occiput_info = occiput_info.Substring(0, occiput_info.Length - 2);

            occ.structure = jsontext[2];
            occ.structure = structure.Substring(structure.IndexOf(": ") + 3);
            occ.structure = structure.Substring(0, structure.Length - 2);

            occ.latin = jsontext[3];
            occ.latin = latin.Substring(latin.IndexOf(": ") + 3);
            occ.latin = latin.Substring(0, latin.Length - 2);

            occ.functions = jsontext[4];
            occ.functions = functions.Substring(functions.IndexOf(": ") + 3);
            occ.functions = functions.Substring(0, functions.Length - 2);

            occ.clinical_significance = jsontext[5];
            occ.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf(": ") + 3);
            occ.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 2);

            occ.first_functional_area = jsontext[6];
            occ.first_functional_area = first_functional_area.Substring(first_functional_area.IndexOf(": ") + 3);
            occ.first_functional_area = first_functional_area.Substring(0, first_functional_area.Length - 2);

            occ.ventral_flow = jsontext[7];
            occ.ventral_flow = ventral_flow.Substring(ventral_flow.IndexOf(": ") + 3);
            occ.ventral_flow = ventral_flow.Substring(0, ventral_flow.Length - 2);

            occ.dorsomedial_flow = jsontext[8];
            occ.dorsomedial_flow = dorsomedial_flow.Substring(dorsomedial_flow.IndexOf(": ") + 3);
            occ.dorsomedial_flow = dorsomedial_flow.Substring(0, dorsomedial_flow.Length - 1);
        }

        // Функція для зчитування з файлу типу .XML
        public void Occiput_XML(string filename, Occiput tmp)
        {
            string[] xmltext = File.ReadAllLines(filename);
            tmp.occiput_info = xmltext[2];
            tmp.occiput_info = occiput_info.Substring(occiput_info.IndexOf("<occiput_name>") + 14);
            tmp.occiput_info = occiput_info.Substring(0, occiput_info.Length - 15);

            tmp.structure = xmltext[3];
            tmp.structure = structure.Substring(structure.IndexOf("<structure>") + 11);
            tmp.structure = structure.Substring(0, structure.Length - 12);

            tmp.latin = xmltext[4];
            tmp.latin = latin.Substring(latin.IndexOf("<latin>") + 7);
            tmp.latin = latin.Substring(0, latin.Length - 8);

            tmp.functions = xmltext[5];
            tmp.functions = functions.Substring(functions.IndexOf("<functions>") + 11);
            tmp.functions = functions.Substring(0, functions.Length - 12);

            tmp.clinical_significance = xmltext[6];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf("<clinical_significance>") + 23);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 24);

            tmp.first_functional_area = xmltext[7];
            tmp.first_functional_area = first_functional_area.Substring(first_functional_area.IndexOf("<first_functional_area>") + 23);
            tmp.first_functional_area = first_functional_area.Substring(0, first_functional_area.Length - 24);

            tmp.ventral_flow = xmltext[8];
            tmp.ventral_flow = ventral_flow.Substring(ventral_flow.IndexOf("<ventral_flow>") + 14);
            tmp.ventral_flow = ventral_flow.Substring(0, ventral_flow.Length - 15);

            tmp.dorsomedial_flow = xmltext[9];
            tmp.dorsomedial_flow = dorsomedial_flow.Substring(dorsomedial_flow.IndexOf("<dorsomedial_flow>") + 18);
            tmp.dorsomedial_flow = dorsomedial_flow.Substring(0, dorsomedial_flow.Length - 19);
        }
    }
}
