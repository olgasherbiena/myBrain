﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.IO;
using System.Collections.Generic;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Brain br;
        bool chek = true;
        public MainWindow()
        {
            InitializeComponent();
            br = new Brain();
            listView.ItemsSource = br.Brains;
            File.AppendAllText("logs/tmplog.txt", "[Entering info search form]\n");
        }

        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Exiting program]\n");
            string log = "logs/" + DateTime.Now.ToString("yyyy-dd-M---HH-mm-ss") + " log.txt";
            string[] logstring = File.ReadAllLines("logs/tmplog.txt");
            File.Create(log).Close();
            File.WriteAllText(log, "[Program started]\n\n------------------------------\n\n");
            File.AppendAllLines(log, logstring);
            File.Delete("logs/tmplog.txt");
            PersonException exception = new PersonException();
            exception.check_log(log);
            if (!exception.get_log())
            { MessageBox.Show("Помилка створення логу", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
            this.Close();
        }
        

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Request.Visibility = Visibility.Collapsed;
            FocusManager.SetFocusedElement(this, Search);
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing info search form]\n[Returning to the main menu form]\n\n------------------------------\n\n");
            Menu_form menu_Form = new Menu_form();
            menu_Form.Show();
            this.Close();
        }

        public int GetId(int index)
        {
            if (index == 0)
                return Cerebellum.id;
            else if (index == 1)
                return Crown.id;
            else if (index == 2)
                return Forehead.id;
            else if (index == 3)
                return Occiput.id;
            else
                return Temporal.id;
        }

        private void find_btn_Click(object sender, RoutedEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing info search form]\n[Opening brain`s part form (pressed find button)]\n\n------------------------------\n\n");
            int selected_id = Convert.ToInt32(listView.SelectedIndex); // Отримуємо id частини мозку, що є першими 3 символами рядка
            if (selected_id != -1) //якщо значення не було знайдено виводить повідомлення
            {
                int id = GetId(selected_id);
                PartInfoForm form = new PartInfoForm(id, br);
                form.Show();
                this.Close();
            }
            else
            {
                chek = false;
                Request.Visibility = Visibility.Visible;
                Request.Content = "Значення не знайдено";
                Search.Clear();
                chek = true;
                
            }
        }

        private void Search_TextChanged_1(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {

            if (chek)
            {
                Find search_implementation = new Find();
                search_implementation.Find_information(Search.Text, listView); // Пошук інформації, який виділяє індекс знайденого елементу у listView
            }
                
            
        }

        private void listView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing info search form]\n[Opening brain`s part form (using listView)]\n\n------------------------------\n\n");
            int selected_item_index = Convert.ToInt32(listView.SelectedIndex); // Отримуємо індекс обраного елемента
            //Search.Text = listView.SelectedIndex.ToString();

            PartInfoForm info_form = new PartInfoForm(GetId(selected_item_index), br); // Створення форми, визначеної за функцією GetId
            info_form.Show();
            Close();
        }

        private void Label_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            Simulation simulation = new Simulation();
            simulation.Show();
            this.Close();
        }
    }
}
