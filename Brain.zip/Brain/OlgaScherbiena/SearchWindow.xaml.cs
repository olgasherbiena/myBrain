﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Brain br;
        public MainWindow()
        {
            InitializeComponent();
            br = new Brain();
            listView.ItemsSource = br.Brains;
        }

        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Request.Visibility = Visibility.Collapsed;
            FocusManager.SetFocusedElement(this, Search);
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Menu_form menu_Form = new Menu_form();
            menu_Form.Show();
            this.Close();
        }

        public int GetId(int index)
        {
            if (index == 0)
                return 101;
            if(index == 4)
                return 202;
            if (index == 3)
                return 102;
            if (index == 2)
                return 120;
            if (index == 1)
                return 110;
            else
                return 202;
        }

        private void find_btn_Click(object sender, RoutedEventArgs e)
        {
            int selected_id = Convert.ToInt32(listView.SelectedIndex); // Отримуємо id частини мозку, що є першими 3 символами рядка
            int id = GetId(selected_id);
            Search.Text = listView.SelectedIndex.ToString();

            PartInfoForm form = new PartInfoForm(id, br);
            form.Show();
            this.Close();
        }

        private void Search_TextChanged_1(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            Find temp = new Find();
            temp.Find_information(Search.Text, listView); // Пошук інформації, який виділяє індекс знайденого елементу у listBo
        }

        private void listView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            int selected_id = Convert.ToInt32(listView.SelectedIndex); // Отримуємо id частини мозку, що є першими 3 символами рядка
            int id = GetId(selected_id);
            Search.Text = listView.SelectedIndex.ToString();

            PartInfoForm form = new PartInfoForm(id, br);
            form.Show();
            this.Close();
        }
    }
}
