﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/Vladislavich7");
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/Vladislavich7");
        }

        private void tgOlga_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/bohgdan_olegovich");
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/bohgdan_olegovich");
        }

        private void tgNastya_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/Nightskyl");
        }

        private void TextBlock_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/Nightskyl");
        }

        private void Image_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/vyv_vyv_vyv");
        }

        private void TextBlock_MouseDown_3(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/vyv_vyv_vyv");
        }

        private void Image_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/Rebootf");
        }

        private void TextBlock_MouseDown_4(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://t.me/Rebootf");
        }

        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Menu_form mainWindow = new Menu_form();
            mainWindow.Show();
            this.Close();
        }
    }
}
