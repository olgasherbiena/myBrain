﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            File.AppendAllText("logs/tmplog.txt", "[Entering developers menu]\n");

            Creators creators = new Creators();
            NasyaName.Content = creators.People[0].initials;

            VladName.Content = creators.People[3].initials;
            VladWork.Content = creators.People[3].task;

            OlgaName.Content = creators.People[4].initials;
            workOlga.Content = creators.People[4].task;

            YaroslavName.Content = creators.People[1].initials;
            YaroslavWork.Content = creators.People[1].task;

            SergiyName.Content = creators.People[2].initials;
            SergiyWork.Content = creators.People[2].task;
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                File.AppendAllText("logs/tmplog.txt", "[Opening class creator telegram]\n");
                Process.Start("https://t.me/Vladislavich7");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Image_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                
                Process.Start("https://t.me/Vladislavich7");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void tgOlga_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try 
            { 
            Process.Start("https://t.me/bohgdan_olegovich");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            try
            { 
            File.AppendAllText("logs/tmplog.txt", "[Opening interface creator telegram]\n");
            Process.Start("https://t.me/bohgdan_olegovich");
        }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
}

        private void tgNastya_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            { 
            Process.Start("https://t.me/Nightskyl");
        }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
}

        private void TextBlock_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            try 
            { 
            File.AppendAllText("logs/tmplog.txt", "[Opening exception handler telegram]\n");
            Process.Start("https://t.me/Nightskyl");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Image_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            try
            { 
            Process.Start("https://t.me/vyv_vyv_vyv");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TextBlock_MouseDown_3(object sender, MouseButtonEventArgs e)
        {
            try
            { 
            File.AppendAllText("logs/tmplog.txt", "[Opening data scientist telegram]\n");
            Process.Start("https://t.me/vyv_vyv_vyv");
        }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
}

        private void Image_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            try 
            { 
            Process.Start("https://t.me/Rebootf");
        }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
}

        private void TextBlock_MouseDown_4(object sender, MouseButtonEventArgs e)
        {
            try
            { 
            File.AppendAllText("logs/tmplog.txt", "[Opening algorythm creator telegram]\n");
            Process.Start("https://t.me/Rebootf");
        }
            catch (Exception ex)
            {
                MessageBox.Show("Посилання є некоректним", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
}

        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Exiting program]\n");
            string log = "logs/" + DateTime.Now.ToString("yyyy-dd-M---HH-mm-ss") + " log.txt";
            string[] logstring = File.ReadAllLines("logs/tmplog.txt");
            File.Create(log).Close();
            File.WriteAllText(log, "[Program started]\n\n------------------------------\n\n");
            File.AppendAllLines(log, logstring);
            File.Delete("logs/tmplog.txt");
            PersonException exception = new PersonException();
            exception.check_log(log);
            if(!exception.get_log())
             { MessageBox.Show("Помилка створення логу", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
            this.Close();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing developers form]\n[Returning to the main menu form]\n\n------------------------------\n\n");
            Menu_form mainWindow = new Menu_form();
            mainWindow.Show();
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Simulation simulation = new Simulation();
            simulation.Show();
            this.Close();
        }

        private void Label_MouseDown_2(object sender, MouseButtonEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
