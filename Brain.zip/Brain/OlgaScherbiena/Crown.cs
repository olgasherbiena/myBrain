﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Brain
{
    public class Crown:Part
    {
        public const int id = 110;
        // Зберігається загальна інформація про тім'яну частину (та що одразу після заголовку)
        private string crown_info; 
        private string lateral_intraparietal_area;
        private string ventral_intraparietal_area;
        private string medial_intraparietal_area;
        private string front_intraparietal_area;
        public Crown()
        {
            name_part = "Тім'яна частина";
            crown_info = "crw_part";
            structure = "crw_struct";
            latin = "crw_lat";
            functions = "crw_func";
            clinical_significance = "crw_clinic";
            lateral_intraparietal_area = "crw_1";
            ventral_intraparietal_area = "crw_2";
            medial_intraparietal_area = "crw_3";
            front_intraparietal_area = "crw_4";
            function_for_list = "сенсорна функція";
        }
        // Доступ до закритих членів класу
        public string Crown_info { set { crown_info = value; } get { return crown_info; } }
        public string Lateral_intraparietal_area { set { lateral_intraparietal_area = value; } get { return lateral_intraparietal_area; } }
        public string Ventral_intraparietal_area { set { ventral_intraparietal_area = value; } get { return ventral_intraparietal_area; } }
        public string Medial_intraparietal_area { set { medial_intraparietal_area = value; } get { return medial_intraparietal_area; } }
        public string Front_intraparietal_area { set { front_intraparietal_area = value; } get { return front_intraparietal_area; } }
        public override string ToString()
        {
            return $"{this.name_part} ({this.latin}): {this.function_for_list}";
        }

        public void Crown_Deserealise(string filename, Crown tmp)
        {
            try
            {
                string[] jsontext = File.ReadAllLines(filename);
                tmp.crown_info = jsontext[1];
                tmp.crown_info = crown_info.Substring(crown_info.IndexOf(": ") + 3);
                tmp.crown_info = crown_info.Substring(0, crown_info.Length - 2);

                tmp.structure = jsontext[2];
                tmp.structure = structure.Substring(structure.IndexOf(": ") + 3);
                tmp.structure = structure.Substring(0, structure.Length - 2);

                tmp.latin = jsontext[3];
                tmp.latin = latin.Substring(latin.IndexOf(": ") + 3);
                tmp.latin = latin.Substring(0, latin.Length - 2);

                tmp.functions = jsontext[4];
                tmp.functions = functions.Substring(functions.IndexOf(": ") + 3);
                tmp.functions = functions.Substring(0, functions.Length - 2);

                tmp.clinical_significance = jsontext[5];
                tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf(": ") + 3);
                tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 2);

                tmp.lateral_intraparietal_area = jsontext[6];
                tmp.lateral_intraparietal_area = lateral_intraparietal_area.Substring(lateral_intraparietal_area.IndexOf(": ") + 3);
                tmp.lateral_intraparietal_area = lateral_intraparietal_area.Substring(0, lateral_intraparietal_area.Length - 2);

                tmp.ventral_intraparietal_area = jsontext[7];
                tmp.ventral_intraparietal_area = ventral_intraparietal_area.Substring(ventral_intraparietal_area.IndexOf(": ") + 3);
                tmp.ventral_intraparietal_area = ventral_intraparietal_area.Substring(0, ventral_intraparietal_area.Length - 2);

                tmp.medial_intraparietal_area = jsontext[8];
                tmp.medial_intraparietal_area = medial_intraparietal_area.Substring(medial_intraparietal_area.IndexOf(": ") + 3);
                tmp.medial_intraparietal_area = medial_intraparietal_area.Substring(0, medial_intraparietal_area.Length - 2);

                tmp.front_intraparietal_area = jsontext[9];
                tmp.front_intraparietal_area = front_intraparietal_area.Substring(front_intraparietal_area.IndexOf(": ") + 3);
                tmp.front_intraparietal_area = front_intraparietal_area.Substring(0, front_intraparietal_area.Length - 1);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не знайдено\n" + ex.FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public void Crown_XML(string filename, Crown tmp)
        {
            try
            { 
            string[] xmltext = File.ReadAllLines(filename);
            tmp.crown_info = xmltext[2];
            tmp.crown_info = crown_info.Substring(crown_info.IndexOf("<crown_name>") + 12);
            tmp.crown_info = crown_info.Substring(0, crown_info.Length - 13);

            tmp.structure = xmltext[3];
            tmp.structure = structure.Substring(structure.IndexOf("<structure>") + 11);
            tmp.structure = structure.Substring(0, structure.Length - 12);

            tmp.latin = xmltext[4];
            tmp.latin = latin.Substring(latin.IndexOf("<latin>") + 7);
            tmp.latin = latin.Substring(0, latin.Length - 8);

            tmp.functions = xmltext[5];
            tmp.functions = functions.Substring(functions.IndexOf("<functions>") + 11);
            tmp.functions = functions.Substring(0, functions.Length - 12);

            tmp.clinical_significance = xmltext[6];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf("<clinical_significance>") + 23);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 24);

            tmp.lateral_intraparietal_area = xmltext[7];
            tmp.lateral_intraparietal_area = lateral_intraparietal_area.Substring(lateral_intraparietal_area.IndexOf("<lateral_intraparietal_area>") + 28);
            tmp.lateral_intraparietal_area = lateral_intraparietal_area.Substring(0, lateral_intraparietal_area.Length - 29);

            tmp.ventral_intraparietal_area = xmltext[8];
            tmp.ventral_intraparietal_area = ventral_intraparietal_area.Substring(ventral_intraparietal_area.IndexOf("<ventral_intraparietal_area>") + 28);
            tmp.ventral_intraparietal_area = ventral_intraparietal_area.Substring(0, ventral_intraparietal_area.Length - 29);

            tmp.medial_intraparietal_area = xmltext[9];
            tmp.medial_intraparietal_area = medial_intraparietal_area.Substring(medial_intraparietal_area.IndexOf("<medial_intraparietal_area>") + 27);
            tmp.medial_intraparietal_area = medial_intraparietal_area.Substring(0, medial_intraparietal_area.Length - 28);

            tmp.front_intraparietal_area = xmltext[10];
            tmp.front_intraparietal_area = front_intraparietal_area.Substring(front_intraparietal_area.IndexOf("<front_intraparietal_area>") + 26);
            tmp.front_intraparietal_area = front_intraparietal_area.Substring(0, front_intraparietal_area.Length - 27);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не знайдено\n" + ex.FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
