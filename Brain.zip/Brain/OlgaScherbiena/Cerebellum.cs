﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Brain
{
    public class Cerebellum : Part
    {
        public const int id = 101;
        // Зберігається загальна інформація про мозечок (та що одразу після заголовку)
        private string cerebellum_info;
        public Cerebellum()// змінна variation створена тільки для імітації роботи з файлом
        {
                name_part = "Мозечок";
                cerebellum_info = "crb_part";
                structure = "crb_struct";
                latin = "crb_lat";
                functions = "crb_func";
                clinical_significance = "crb_clinic";
                function_for_list = "координація та рух";
        }
        // Доступ до закритого члену класу
        public string Cerebellum_info { set { cerebellum_info = value; } get{ return cerebellum_info; } }
        public override string ToString()
        {
            return $"{this.name_part} ({this.latin}): {this.function_for_list}";
        }

        // Функція для зчитування інформації з файлу типу .JSON
        public void Cerebellum_Deserealise(string filename, Cerebellum tmp)
        {
            string[] jsontext = File.ReadAllLines(filename);
            tmp.cerebellum_info = jsontext[1];
            tmp.cerebellum_info = cerebellum_info.Substring(cerebellum_info.IndexOf(": ") + 3);
            tmp.cerebellum_info = cerebellum_info.Substring(0, cerebellum_info.Length - 2);

            tmp.structure = jsontext[2];
            tmp.structure = structure.Substring(structure.IndexOf(": ") + 3);
            tmp.structure = structure.Substring(0, structure.Length - 2);

            tmp.latin = jsontext[3];
            tmp.latin = latin.Substring(latin.IndexOf(": ") + 3);
            tmp.latin = latin.Substring(0, latin.Length - 2);

            tmp.functions = jsontext[4];
            tmp.functions = functions.Substring(functions.IndexOf(": ") + 3);
            tmp.functions = functions.Substring(0, functions.Length - 2);

            tmp.clinical_significance = jsontext[5];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf(": ") + 3);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 1);
        }

        // Функція для зчитування з файлу типу .XML
        public void Cerebellum_XML(string filename, Cerebellum tmp)
        {
            string[] xmltext = File.ReadAllLines(filename);
            tmp.cerebellum_info = xmltext[2];
            tmp.cerebellum_info = cerebellum_info.Substring(cerebellum_info.IndexOf("<cerebellum_name>") + 17);
            tmp.cerebellum_info = cerebellum_info.Substring(0, cerebellum_info.Length - 18);

            tmp.structure = xmltext[3];
            tmp.structure = structure.Substring(structure.IndexOf("<structure>") + 11);
            tmp.structure = structure.Substring(0, structure.Length - 12);

            tmp.latin = xmltext[4];
            tmp.latin = latin.Substring(latin.IndexOf("<latin>") + 7);
            tmp.latin = latin.Substring(0, latin.Length - 8);

            tmp.functions = xmltext[5];
            tmp.functions = functions.Substring(functions.IndexOf("<functions>") + 11);
            tmp.functions = functions.Substring(0, functions.Length - 12);

            tmp.clinical_significance = xmltext[6];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf("<clinical_significance>") + 23);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 24);
        }

    }
}
