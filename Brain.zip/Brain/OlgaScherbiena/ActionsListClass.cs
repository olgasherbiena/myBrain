﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brain
{
    class ActionsListClass
    {
        // <Назва дії : <id частини мозку : часова затримка>
        public Dictionary<String, Dictionary<int, int>> actions; 
        public ActionsListClass()
        {
            actions = new Dictionary<string, Dictionary<int, int>>();
            actions.Add("Ходьба", new Dictionary<int, int>{ 
                { 101, 3000 },
                { 120, 3000 } });
            actions.Add("Моторика рук", new Dictionary<int, int>{
                { 120, 3000 } });
            actions.Add("Зір", new Dictionary<int, int>{
                { 102, 3000 } });
            actions.Add("Пам'ять", new Dictionary<int, int>{
                { 120, 3000 },
                { 202, 3000 } });
            actions.Add("Мовлення", new Dictionary<int, int>{
                { 120, 3000 } });
            actions.Add("Слух", new Dictionary<int, int>{
                { 110, 3000 } });
            actions.Add("Смак", new Dictionary<int, int>{
                { 110, 3000 },
                { 120, 3000 } });
            actions.Add("Інтелект", new Dictionary<int, int>{
                { 110, 3000 } });
            actions.Add("Емоції", new Dictionary<int, int>{
                { 120, 3000 },
                { 202, 3000 } });
            actions.Add("Сон", new Dictionary<int, int>{
                { 120, 3000 } });
        }
    }
}
