﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Brain
{
    public class Temporal: Part
    {
        public const int id = 202;
        // Зберігається загальна інформація про скроневу частину (та що одразу після заголовку)
        private string temporal_info; 
        // Обробка сенсорного введення
        public struct touch_input_processing 
        {
            public string otic;
            public string visual;
            public string speech_recognition;
        }
        private touch_input_processing function;
        public Temporal()
        {
            name_part = "Скронева частина";
            temporal_info = "tmp_part";
            structure = "tmp_struct";
            latin = "tmp_lat";
            functions = "tmp_func";
            function.otic = "tmp1";
            function.visual = "tmp2";
            function.speech_recognition = "tmp3";
            clinical_significance = "tmp4";
            function_for_list = "мовлення та пам'ять";
        }
        public string Temporal_info { set { temporal_info = value; } get { return temporal_info; } }
        public touch_input_processing Function { set { } get { return function; } }
        public override string ToString()
        {
            return $"{this.name_part} ({this.latin}): {this.function_for_list}";
        }
        public void Temporal_Deserealise(string filename, Temporal tmp)
        {
            try
            { 
            string[] jsontext = File.ReadAllLines(filename);
            tmp.temporal_info = jsontext[1];
            tmp.temporal_info = temporal_info.Substring(temporal_info.IndexOf(": ") + 3);
            tmp.temporal_info = temporal_info.Substring(0, temporal_info.Length - 2);

            tmp.structure = jsontext[2];
            tmp.structure = structure.Substring(structure.IndexOf(": ") + 3);
            tmp.structure = structure.Substring(0, structure.Length - 2);

            tmp.latin = jsontext[3];
            tmp.latin = latin.Substring(latin.IndexOf(": ") + 3);
            tmp.latin = latin.Substring(0, latin.Length - 2);

            tmp.functions = jsontext[4];
            tmp.functions = functions.Substring(functions.IndexOf(": ") + 3);
            tmp.functions = functions.Substring(0, functions.Length - 2);

            tmp.clinical_significance = jsontext[8];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf(": ") + 3);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 1);

            tmp.function.otic = jsontext[5];
            tmp.function.otic = function.otic.Substring(function.otic.IndexOf(": ") + 3);
            tmp.function.otic = function.otic.Substring(0, function.otic.Length - 2);

            tmp.function.visual = jsontext[6];
            tmp.function.visual = function.visual.Substring(function.visual.IndexOf(": ") + 3);
            tmp.function.visual = function.visual.Substring(0, function.visual.Length - 2);

            tmp.function.speech_recognition = jsontext[7];
            tmp.function.speech_recognition = function.speech_recognition.Substring(function.speech_recognition.IndexOf(": ") + 3);
            tmp.function.speech_recognition = function.speech_recognition.Substring(0, function.speech_recognition.Length - 2);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не знайдено\n" + ex.FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void Temporal_XML(string filename, Temporal tmp)
        {
            try
            { 
            string[] xmltext = File.ReadAllLines(filename);
            tmp.temporal_info = xmltext[2];
            tmp.temporal_info = temporal_info.Substring(temporal_info.IndexOf("<temporal_name>") + 15);
            tmp.temporal_info = temporal_info.Substring(0, temporal_info.Length - 16);

            tmp.structure = xmltext[3];
            tmp.structure = structure.Substring(structure.IndexOf("<structure>") + 11);
            tmp.structure = structure.Substring(0, structure.Length - 12);

            tmp.latin = xmltext[4];
            tmp.latin = latin.Substring(latin.IndexOf("<latin>") + 7);
            tmp.latin = latin.Substring(0, latin.Length - 8);

            tmp.functions = xmltext[5];
            tmp.functions = functions.Substring(functions.IndexOf("<functions>") + 11);
            tmp.functions = functions.Substring(0, functions.Length - 12);

            tmp.clinical_significance = xmltext[9];
            tmp.clinical_significance = clinical_significance.Substring(clinical_significance.IndexOf("<clinical_significance>") + 23);
            tmp.clinical_significance = clinical_significance.Substring(0, clinical_significance.Length - 24);

            tmp.function.otic = xmltext[6];
            tmp.function.otic = function.otic.Substring(function.otic.IndexOf("<function.otic>") + 15);
            tmp.function.otic = function.otic.Substring(0, function.otic.Length - 16);

            tmp.function.visual = xmltext[7];
            tmp.function.visual = function.visual.Substring(function.visual.IndexOf("<function.visual>") + 17);
            tmp.function.visual = function.visual.Substring(0, function.visual.Length - 18);

            tmp.function.speech_recognition = xmltext[8];
            tmp.function.speech_recognition = function.speech_recognition.Substring(function.speech_recognition.IndexOf("<function.speech_recognition>") + 29);
            tmp.function.speech_recognition = function.speech_recognition.Substring(0, function.speech_recognition.Length - 30);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не знайдено\n" + ex.FileName, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
