﻿using System;
using System.Collections;
using System.Text;
using System.Xml;

namespace Brain
{
    public class XML
    {
        public string filenameLoad;
        public string filenameUpload;
        public XML(string Load, string Upload)
        {
            filenameLoad = Load;
            filenameUpload = Upload;
        }
       public void ForLoad(string filenameLoad, Brain brain) { } // функція для запису в файл
       public void ForUpload(string filenameUpload, Brain brain) { } // функція для зчитування з файлу

    }
}
