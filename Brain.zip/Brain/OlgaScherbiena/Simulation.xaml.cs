﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Net.Http;
using System.IO;

namespace Brain
{
    /// <summary>
    /// Логика взаимодействия для Simulation.xaml
    /// </summary>
    public partial class Simulation : Window
    {
        public Simulation()
        {
            File.AppendAllText("logs/tmplog.txt", "[Entering brain simulation menu]\n");
            InitializeComponent();
        }
        public bool check_activ = true;
        private void Close_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Exiting program]\n");
            string log = "logs/" + DateTime.Now.ToString("yyyy-dd-M---HH-mm-ss") + " log.txt";
            string[] logstring = File.ReadAllLines("logs/tmplog.txt");
            File.Create(log).Close();
            File.WriteAllText(log, "[Program started]\n\n------------------------------\n\n");
            File.AppendAllLines(log, logstring);
            File.Delete("logs/tmplog.txt");
            PersonException exception = new PersonException();
            exception.check_log(log);
            if (!exception.get_log())
            { MessageBox.Show("Помилка створення логу", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
            this.Close();
        }

        private void Label_MouseDown(object sender, MouseButtonEventArgs e)
        {
            File.AppendAllText("logs/tmplog.txt", "[Closing brain simulation form]\n[Returning to the main menu form]\n\n------------------------------\n\n");
            Menu_form menu_Form = new Menu_form();
            menu_Form.Show();
            this.Close();
        }

        private void Label_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            MainWindow mainwind = new MainWindow();
            mainwind.Show();
            this.Close();
        }
        private void outputParts(int s)
        {
            PartInfoForm partInfoForm = new PartInfoForm();
            label1.Content = partInfoForm.GetPart(s).name_part + ":" + partInfoForm.GetPart(s).function_for_list;
            PersonException exception = new PersonException();
            exception.assembly();
            if (exception.get_png())
            {
                if (partInfoForm.GetPart(s).name_part == "Лобова частина")
                {
                    Uri resourceUri = new Uri("/Assets/front part.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else if (partInfoForm.GetPart(s).name_part == "Скронева частина")
                {
                    Uri resourceUri = new Uri("/Assets/temporal part.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else if (partInfoForm.GetPart(s).name_part == "Тім'яна частина")
                {
                    Uri resourceUri = new Uri("/Assets/parietal part.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else if (partInfoForm.GetPart(s).name_part == "Мозечок")
                {
                    Uri resourceUri = new Uri("/Assets/mozochok.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else if (partInfoForm.GetPart(s).name_part == "Потилична частина")
                {
                    Uri resourceUri = new Uri("/Assets/occipital part.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }


                partInfoForm.Close();
            }
            else
            {
                MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
        private async void memory_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                memory.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[memory.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Memory button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                label1.Content = string.Empty;
                memory.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }

        }

        private async void intelligence_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ=false;
                intelligence.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[intelligence.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Intelligence button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

                

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                label1.Content = string.Empty;
                intelligence.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ=true;
            }
        }

        private async void speech_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                speech.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[speech.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Speech button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }


                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }


                label1.Content = string.Empty;
                speech.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ=true;
            }
    }

        private async void sleep_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                sleep.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[sleep.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Sleep button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }


                label1.Content = string.Empty;
                sleep.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }
        }

        private async void taste_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                taste.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[taste.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Taste button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                label1.Content = string.Empty;
                taste.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }
        }

        private async void Walking_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                Walking.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[Walking.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Walking button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }


                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }


                label1.Content = string.Empty;
                Walking.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }
        }

        private async void emotions_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                emotions.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[emotions.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Emotions button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }


                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }


                label1.Content = string.Empty;
                emotions.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }
        }

        private async void motorSkillsOfHands_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                motorSkillsOfHands.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[emotions.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Motor skills button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }


                label1.Content = string.Empty;
                motorSkillsOfHands.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }
        }

        private async void vision_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                vision.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

                ActionsListClass ac = new ActionsListClass();
                var chosen_action = ac.actions[vision.Content.ToString()];
                foreach (var el in chosen_action)
                {
                    File.AppendAllText("logs/tmplog.txt", "[Vision button pressed]\n");
                    outputParts(el.Key);
                    // Затримка перед переходом до іншої частини
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }


                label1.Content = string.Empty;
                vision.IsEnabled = true; // Знову "активуємо" кнопку
                check_activ = true;
            }
        }

        private async void hearing_Click(object sender, RoutedEventArgs e)
        {
            if (check_activ)
            {
                check_activ = false;
                hearing.IsEnabled = false; // Робимо кнопку неактивною, щоб запобігти неправильної роботи алгоритму

            ActionsListClass ac = new ActionsListClass();
            var chosen_action = ac.actions[hearing.Content.ToString()];
            foreach (var el in chosen_action)
            {
                    File.AppendAllText("logs/tmplog.txt", "[Hearing button pressed]\n");
                    outputParts(el.Key);
                // Затримка перед переходом до іншої частини
                await Task.Delay(TimeSpan.FromSeconds(3));
            }

                PersonException exception = new PersonException();
                exception.assembly();
                if (exception.get_png())
                {
                    Uri resourceUri = new Uri("/Assets/brainstorm.png", UriKind.Relative);
                    BrainImg.Source = new BitmapImage(resourceUri);
                }
                else
                {
                    MessageBox.Show("Помилка відкриття зображення", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }

                label1.Content = string.Empty;
            hearing.IsEnabled = true; // Знову "активуємо" кнопку
            check_activ = true;
        }
        }
    }
}
