﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Brain
{
    public class JSON
    {
        public JSON()
        {
           
        }
        public void Serialize(string filenameSerialize, object brain) {   } // Функція для запису в файл
        public void Deserialize(string filenameDeserialize, object brain) { } // Функція для зчитування з файлу
    }
}
