﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Brain
{
    // Абстрактний клас, який містить спільні рядки для частин мозку
    public abstract class Part
    {
       public string structure;
       public string latin;
       public string functions;
       public string clinical_significance;
    }
    // Клас, який вміщує у себе всі 5 частин головного мозку
    public class Brain : Part
    {
        // Тім'яна чатсина
        private Crown cr;
        // Мозечок
        private Cerebellum cer;
        // Лобова частина
        private Forehead fr;
        // Потилична частина
        private Occiput occ;
        // Скронева частина
        private Temporal tmp;
        // Список для пошуку інформаціх
        private List<Part> brains;
        public Brain()
        {
            cer = new Cerebellum();
            cr = new Crown();
            fr = new Forehead();
            occ = new Occiput();
            tmp = new Temporal();
            // Заповнюємо список
            brains = new List<Part>();
            {
                brains.Add(cer);
                brains.Add(cr);
                brains.Add(fr);
                brains.Add(occ);
                brains.Add(tmp);
            }
        }
        // Доступ до закритих членів класу за його межами
        public List<Part> Brains { set { } get { return brains; } }
        public Crown Cr { set { } get { return cr; } }
        public Cerebellum Cer { set { } get { return cer; } }
        public Forehead Fr { set { } get { return fr; } }
        public Occiput Occ { set { } get { return occ; } }
        public Temporal Tmp { set { } get { return tmp; } }
        /*public override string ToString()
        {
            return string.Format("This is brain {0}", brains.ToString());
        }*/
    }
}
