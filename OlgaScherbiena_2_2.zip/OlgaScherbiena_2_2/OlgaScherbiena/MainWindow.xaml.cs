﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace OlgaScherbiena
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            ListView1.Items.Add("Тім'яна ділянка");
            ListView1.Items.Add("Тім'яна ділянка");
            ListView1.Items.Add("Тім'яна ділянка");
            ListView1.Items.Add("Тім'яна ділянка");
            ListView1.Items.Add("Тім'яна ділянка");
            ListView1.Items.Add("Тім'яна ділянка");
           // ListView2.Items.Add("Тім'яна ділянка");
        }

        private void border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            while (ListView1.SelectedIndex >= 0)
            {
                ListView1.Items.RemoveAt(ListView1.SelectedIndex);
            }
        }
    }
}
